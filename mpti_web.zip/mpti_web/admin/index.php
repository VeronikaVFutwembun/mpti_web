<?php
session_start();
include '../koneksi.php';

// Cek login admin
if($_SESSION['level'] != "admin"){
    header("location:../login.php");
}

// Load template UI jika ada
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Sistem Keluhan Mahasiswa</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<?php include 'sidebar.php'; ?>  <!-- jika pakai sidebar, boleh hapus kalau tidak ada -->

<div class="content">

<?php
// Routing Halaman Admin
if(isset($_GET['url'])){
    $hal = $_GET['url'];

    switch ($hal){

        case 'verifikasi-keluhan':
            include 'verifikasi-keluhan.php';
        break;

        case 'detail':
            include 'detail-keluhan.php';
        break;

        case 'proses-verifikasi':
            include 'proses-verifikasi.php';
        break;

        default:
            echo "<h3>Halaman tidak ditemukan!</h3>";
        break;

    }
} else {
    echo "<h3>Selamat datang Admin!</h3>";
}
?>

</div>

</body>
</html>
