<?php
include "../koneksi.php";

$id = $_GET['id'];

mysqli_query($koneksi,"UPDATE keluhan SET status='proses' WHERE id_keluhan='$id'");

echo "<script>
alert('Keluhan berhasil diverifikasi & diteruskan ke petugas');
window.location='admin.php?url=verifikasi-keluhan';
</script>";
?>
