<div class="sidebar">
    <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="index.php?url=verifikasi-keluhan">Verifikasi Keluhan</a></li>
        <li><a href="../logout.php">Logout</a></li>
    </ul>
</div>
