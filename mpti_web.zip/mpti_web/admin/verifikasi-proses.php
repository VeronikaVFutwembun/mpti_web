<?php
include '../koneksi.php';

if(isset($_GET['id'])){
    $id = $_GET['id'];

    // update status dari '0' menjadi 'proses' atau 'diterima'
    $update = mysqli_query($koneksi, 
        "UPDATE keluhan SET status='proses' WHERE id_keluhan='$id'"
    );

    if($update){
        echo "<script>
                alert('Keluhan berhasil diverifikasi!');
                window.location='admin.php?url=verifikasi-keluhan';
              </script>";
    } else {
        echo "<script>
                alert('Verifikasi gagal!');
                window.location='admin.php?url=verifikasi-keluhan';
              </script>";
    }
} else {
    echo "<script>
            alert('ID tidak ditemukan!');
            window.location='admin.php?url=verifikasi-keluhan';
          </script>";
}
?>
