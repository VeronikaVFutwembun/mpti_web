<?php
include '../koneksi.php';

// ambil semua keluhan dengan status 'baru'
$data = mysqli_query($koneksi,"SELECT * FROM keluhan WHERE status='0'");
?>

<h3>Daftar Keluhan Untuk Verifikasi Admin</h3>
<table class="table table-bordered">
    <tr>
        <th>NPM</th>
        <th>Tanggal</th>
        <th>Isi Keluhan</th>
        <th>Foto</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>

<?php while($d = mysqli_fetch_array($data)){ ?>
<tr>
    <td><?= $d['npm']; ?></td>
    <td><?= $d['tgl_keluhan']; ?></td>
    <td><?= substr($d['isi_keluhan'],0,50) ?>...</td>
    <td><img src="../foto/<?= $d['foto']; ?>" width="60"></td>
    <td><?= $d['status']; ?></td>

    <td>
        <a href="verifikasi-proses.php?id=<?= $d['id_keluhan']; ?>" 
           class="btn btn-success btn-sm">Verifikasi</a>
    </td>
</tr>
<?php } ?>
</table>
