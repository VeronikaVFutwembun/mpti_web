<?php
if(isset($_GET['url'])){
    switch($_GET['url']){
        case 'verifikasi-keluhan':
            include 'verifikasi-keluhan.php';
            break;

        case 'detail-keluhan':
            include 'detail-keluhan.php';
            break;

        default:
            echo "Halaman tidak ditemukan!";
            break;
    }
} else {
    echo "Selamat Datang Admin!<br>Sistem Keluhan Mahasiswa";
}
?>
