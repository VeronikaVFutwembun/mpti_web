<?php

$id = $_GET['id'];
if(empty($id)){
    header("Location:mahasiswa.php");
}
include 'koneksi.php';
$query = mysqli_query($koneksi, "SELECT * FROM keluhan WHERE id_keluhan='$id'");
$data = mysqli_fetch_array($query);

?>
<div class="card-shadow">
    <div class="card-header">
        <a href="?url=lihat-keluhan" class="btn btn-primary btn-icon-split">
            <span class="icon text-white-5">
                <i class="fa fa-arrow-left"></i>
            </span>
            <span class="text">Kembali</span>
        </a>
    </div>
    <div class="card-body">
        <form method="post" action="proses-keluhan.php" enctype="multipart/form-data">

            <div class="form-group">
                <label style="font-size: 14px" >Tgl Keluhan</label>
                <input type="date" name="tgl_keluhan" class="form-control" readonly value="<?= 
                $data ['tgl_keluhan']?>" required>
            </div>

            <div class="form-group">
                <label style="font-size: 14px" >Isi Keluhan </label>
                <textarea name="isi_keluhan" class="form-control" required> <?= $data['isi_keluhan'] ?></textarea>
            </div>

            <div class="form-group">
                <label style="font-size: 14px" >Foto</label>
                <img class="img-thumbnail" src="foto/<?= $data['foto']?>" width="300px">
            </div>
        </form>
    </div>
</div>