<?php
include '../koneksi.php';

// ambil hanya laporan yang belum selesai
$data = mysqli_query($koneksi,"SELECT * FROM keluhan WHERE status='0' OR status='proses'");
?>

<h3>Daftar Keluhan Mahasiswa</h3>
<table class="table table-bordered">
    <tr>
        <th>NPM</th>
        <th>Isi Keluhan</th>
        <th>Tanggal</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>

<?php
while($d = mysqli_fetch_array($data)){
?>
<tr>
    <td><?= $d['npm']; ?></td> <!-- fix: tadinya nim -->
    <td><?= substr($d['isi_keluhan'],0,40) ?>...</td>  <!-- fix tidak ada kolom judul -->
    <td><?= $d['tgl_keluhan']; ?></td>
    <td>
        <?php if($d['status']=="0"){ echo "Menunggu"; } ?>
        <?php if($d['status']=="proses"){ echo "Diproses"; } ?>
        <?php if($d['status']=="selesai"){ echo "Selesai"; } ?>
    </td>
    <td>
        <a href="petugas.php?url=beri-tanggapan&id_keluhan=<?= $d['id_keluhan']; ?>" 
           class="btn btn-primary btn-sm">
           Tanggapi
        </a>
    </td>
</tr>
<?php } ?>
</table>
