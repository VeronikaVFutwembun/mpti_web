<?php
include '../koneksi.php';

if(!isset($_GET['id_keluhan'])){
    echo "<script>alert('ID tidak ditemukan');window.location='petugas.php?url=tanggapi-keluhan';</script>";
    exit;
}

$id = $_GET['id_keluhan']; // FIX disini

// Ambil data keluhan berdasarkan ID
$query = mysqli_query($koneksi,"SELECT * FROM keluhan WHERE id_keluhan='$id'");
$data = mysqli_fetch_assoc($query);

?>

<h3>Form Tanggapan</h3>
<hr>

<table class="table table-bordered">
    <tr>
        <th>NPM</th>
        <td><?= $data['npm']; ?></td>
    </tr>
    <tr>
        <th>Isi Keluhan</th>
        <td><?= $data['isi_keluhan']; ?></td>
    </tr>
    <tr>
        <th>Tanggal</th>
        <td><?= $data['tgl_keluhan']; ?></td>
    </tr>
    <tr>
        <th>Foto</th>
        <td><img src="../foto/<?= $data['foto']; ?>" width="250"></td>
    </tr>
</table>

<form method="POST" action="proses-tanggapan.php">
    <input type="hidden" name="id_keluhan" value="<?= $data['id_keluhan']; ?>">

    <label>Tanggapan:</label>
    <textarea name="tanggapan" class="form-control" required></textarea><br>

    <label>Status Keluhan:</label>
    <select name="status" class="form-control" required>
        <option value="proses">Proses</option>
        <option value="selesai">Selesai</option>
    </select><br>

    <button class="btn btn-primary">Kirim Tanggapan</button>
</form>
