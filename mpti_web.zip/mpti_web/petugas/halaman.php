<?php

if(isset($_GET['url'])){

    switch($_GET['url']){
        case 'tulis-keluhan':
        include 'tulis-keluhan.php';
        break;

        case 'lihat-keluhan':
        include 'lihat-keluhan.php';
        break;

        case 'detail-keluhan':
        include 'detail-keluhan.php';
        break;

        case 'lihat-tanggapan':
        include 'lihat-tanggapan.php';
        break;

        case 'tanggapi-keluhan':
        include 'tanggapi-keluhan.php';
        break;

        case 'beri-tanggapan':
            include 'beri-tanggapan.php';
        break;

        default:
            echo "Halaman tidak ditemukan!";
            break;
    }
} else {
    echo "Selamat Datang di Sistem Keluhan Mahasiswa, Aplikasi ini dibuat untuk melaporkan hal-hal yang menyimpang dari ketentuan. <br>";
    echo "Anda Login sebagai:".$_SESSION['nama_petugas'];
}