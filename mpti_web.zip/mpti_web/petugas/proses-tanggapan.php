<?php
include '../koneksi.php';
session_start();

$id = $_POST['id_keluhan'];
$tanggapan = $_POST['tanggapan'];
$tgl = date('Y-m-d');
$petugas = $_SESSION['id_petugas']; // pastikan session sudah ada

mysqli_query($koneksi,"INSERT INTO tanggapan(id_keluhan,tgl_tanggapan,tanggapan,id_petugas) VALUES('$id','$tgl','$tanggapan','$petugas')");

mysqli_query($koneksi,"UPDATE keluhan SET status='selesai' WHERE id_keluhan='$id'");

echo "<script>alert('Tanggapan berhasil dikirim!');location.href='petugas.php?url=tanggapi-keluhan';</script>";
