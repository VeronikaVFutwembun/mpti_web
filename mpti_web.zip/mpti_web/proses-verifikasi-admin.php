<?php
// Pastikan koneksi.php berada di root (sejajar dengan file ini)
include 'koneksi.php'; 

// --- 1. VALIDASI REQUEST ---
if (!isset($_POST['submit_verifikasi'])) {
    header("Location: admin/halaman.php?error=Akses tidak sah.");
    exit;
}

// --- 2. AMBIL DATA DARI FORM ---
$id_keluhan = isset($_POST['id_keluhan']) ? (int)$_POST['id_keluhan'] : 0;
// $status_baru akan berisi 'terverifikasi' atau 'ditolak'
$status_baru = isset($_POST['status_baru']) ? $_POST['status_baru'] : ''; 

// Cek data penting
if ($id_keluhan === 0 || !in_array($status_baru, ['terverifikasi', 'ditolak'])) {
    header("Location: admin/halaman.php?error=Data tidak valid atau tidak lengkap.");
    exit;
}

// --- 3. UPDATE STATUS KELUHAN ---
// Query untuk mengubah status keluhan di tabel 'keluhan'
$query_update = "UPDATE keluhan SET status = ? WHERE id_keluhan = ?";
$stmt_update = mysqli_prepare($koneksi, $query_update);

// Binding parameter: s (string), i (integer)
mysqli_stmt_bind_param($stmt_update, 'si', $status_baru, $id_keluhan);

if (mysqli_stmt_execute($stmt_update)) {
    // Sukses: Redirect kembali ke dashboard admin dengan pesan sukses
    $message = urlencode("Keluhan #$id_keluhan berhasil diubah statusnya menjadi $status_baru.");
    header("Location: admin/admin.php?url=verifikasi-keluhan&success=$message");
} else {
    // Gagal: Redirect kembali ke halaman detail verifikasi dengan pesan error
    $message = urlencode("Gagal memperbarui status: " . mysqli_error($koneksi));
    header("Location: admin/admin.php?url=detail-verifikasi&id=$id_keluhan&error=$message");
}

mysqli_close($koneksi);
?>