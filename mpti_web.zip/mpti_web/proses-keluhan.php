<?php
session_start();
$tgl_keluhan = $_POST['tgl_keluhan'];
$npm = $_SESSION['npm'];
$isi_keluhan = $_POST['isi_keluhan'];
$lokasi_foto = $_FILES['foto']['tmp_name'];
$nama_foto = $_FILES['foto']['name'];
$status = 0;

if(move_uploaded_file($lokasi_foto, 'foto/'.$nama_foto)){
    $sql = "INSERT INTO keluhan (tgl_keluhan, npm, isi_keluhan, foto, status) VALUES ('$tgl_keluhan', '$npm', '$isi_keluhan', '$nama_foto', '$status')";
    include 'koneksi.php';
    if(mysqli_query($koneksi, $sql)){
       echo "<script>alert('Keluhan berhasil dikirim'); 
       window.location.assign('mahasiswa.php');</script>";
    } else {
       echo "<script>alert('Keluhan gagal dikirim'); 
       window.location.assign('mahasiswa.php?url=tulis-keluhan');</script>";
}
}