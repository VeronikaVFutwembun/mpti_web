<?php

$npm = $_POST['npm'];
$nama = $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];
$telp = $_POST['telp'];

include 'koneksi.php';

$sql = "INSERT INTO mahasiswa (npm, nama, username, password, telp) VALUES ('$npm', '$nama', '$username', '$password', '$telp')";

if (mysqli_query($koneksi, $sql)) {
    echo "<script>alert('Registrasi Berhasil! Silahkan Login.');window.location.assign('index.php');</script>";
} else {
    echo "<script>alert('Andna Gagal Mendaftar.');window.location.assign('register.php');</script>";
}