<?php

$npm = $_POST['npm'];
$password = $_POST['password'];

include 'koneksi.php';
$sql        = ("SELECT * FROM mahasiswa WHERE npm='$npm' AND password='$password'");
$query      = mysqli_query($koneksi, $sql);

if(mysqli_num_rows($query)>0){
    session_start();
    $_SESSION['npm'] = $npm;
    $data = mysqli_fetch_array($query);
    $_SESSION['nama'] = $data['nama'];
    $_SESSION['username'] = $data['username'];
    header("Location:mahasiswa.php");
} else {
    echo "<script>alert('Login Gagal: Cek NPM dan Password Anda!'); window.location.assign('index.php');</script>";
}