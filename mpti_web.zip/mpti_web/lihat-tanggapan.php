<?php

$id = $_GET['id'];
if(empty($id)){
    header("Location:mahasiswa.php");
}
include 'koneksi.php';
$query = mysqli_query($koneksi, "SELECT * FROM keluhan, tanggapan WHERE tanggapan.id_keluhan='$id' AND tanggapan.id_keluhan=keluhan.id_keluhan");

?>
<div class="card-shadow">
    <div class="card-header">
        <a href="?url=lihat-keluhan" class="btn btn-primary btn-icon-split">
            <span class="icon text-white-5">
                <i class="fa fa-arrow-left"></i>
            </span>
            <span class="text">Kembali</span>
        </a>
    </div>
    <div class="card-body">
        <?php
    if(mysqli_num_rows($query) == 0){
    echo "<div class='alert alert-danger'>Tanggapan belum tersedia</div>";
    }else{
    $data = mysqli_fetch_array($query);?>


        <form method="post" action="proses-keluhan.php" enctype="multipart/form-data">

            <div class="form-group">
                <label style="font-size: 14px" >Tgl Keluhan</label>
                <input type="date" name="tgl_keluhan" class="form-control" readonly value="<?= 
                $data ['tgl_tanggapan']?>" required>
            </div>

            <div class="form-group">
                <label style="font-size: 14px" >Keluhan </label>
                <textarea name="isi_keluhan" class="form-control" required> <?= $data['isi_keluhan'] ?></textarea>
            </div>

            <div class="form-group">
                <label style="font-size: 14px" >Tanggapan </label>
                <textarea name="isi_keluhan" class="form-control" required> <?= $data['tanggapan'] ?></textarea>
            </div>
        </form>
        <?php } ?>
    </div>
</div>