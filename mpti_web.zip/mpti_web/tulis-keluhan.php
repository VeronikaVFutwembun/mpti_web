<div class="card-shadow">
    <div class="card-header">
        <a href="mahasiswa.php" class="btn btn-primary btn-icon-split">
            <span class="icon text-white-5">
                <i class="fa fa-arrow-left"></i>
            </span>
            <span class="text">Kembali</span>
        </a>
    </div>
    <div class="card-body">
        <form method="post" action="proses-keluhan.php" enctype="multipart/form-data">

            <div class="form-group">
                <label style="font-size: 14px" >Tgl Keluhan</label>
                <input type="date" name="tgl_keluhan" class="form-control" readonly value="<?= date('Y-m-d'); ?>" required>
            </div>

            <div class="form-group">
                <label style="font-size: 14px" >Isi Keluhan </label>
                <textarea name="isi_keluhan" class="form-control" required></textarea>
            </div>

            <div class="form-group">
                <label style="font-size: 14px" >Foto</label>
                <input type="file" required name="foto" class="form-control" accept="image/*">
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-success">Simpan</button>
            </div>
        </form>
    </div>
</div>